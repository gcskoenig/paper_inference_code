setwd('~/university/phd/2022/research/paper_inference/repos/iml-uq/')

library(ggplot2)
library(data.table)

fig_dir = '~'

df = read.csv('submission/results/run-1669290942/pdp/conditional/0-thalach.csv')
#df = read.csv('submission/results/run-1669657201/pdp/conditional/rf-thalach.csv')

theme_set(theme_minimal() + theme(text = element_text(size = 10)))

pdps = df['pdp']
pdps['feature'] = df['xj']
pdps['upper'] = pdps['pdp'] + df['ci_delta']
pdps['lower'] = pdps['pdp'] - df['ci_delta']
pdps['uqtype'] = df['uqtype']

if (is.numeric(pdps$feature)) {
  p_pdp = ggplot(pdps, aes_string(x = 'feature')) +
    geom_line(aes(y = pdp)) +
    geom_line(aes(y = upper), lty = 2) + 
    geom_line(aes(y = lower), lty = 2) +
    scale_y_continuous("PD") +
    scale_x_continuous('thalach') +
    facet_wrap('uqtype')
} else {
  p_pdp = ggplot(pdps, aes(x = feature)) +
    geom_point(aes(y = pdp)) +
    geom_segment(aes(xend=feature, y = lower, yend = upper)) +
    scale_y_continuous("PDP") +
    scale_x_discrete("") +
    facet_wrap('uqtype')
}

plot(p_pdp)
ggsave(sprintf("%s/pdp_application.pdf", fig_dir), width = 8, height = 3)


df_pfi = read.csv('submission/results/run-1669290942/pfi/conditional/fis_brier-0_diff.csv')
# df_pfi = read.csv('submission/results/run-1669657201/pfi/conditional/fis_brier-rf_diff.csv')

pfis = df_pfi['feature']
pfis['pfi'] = df_pfi['fi']
pfis['lower'] = df_pfi['fi'] - df_pfi['ci_delta']
pfis['upper'] = df_pfi['fi'] + df_pfi['ci_delta']
pfis['uqtype'] = df_pfi['uqtype']

pfis_model = pfis[pfis$uqtype == 'model',]
pfis_learner = pfis[pfis$uqtype == 'learner',]
ordering = order(pfis_learner$pfi)
pfis_model = pfis_model[ordering,]
pfis_learner = pfis_learner[ordering,]
pfis_model$feature = factor(pfis_model$feature, levels=pfis_model$feature)
pfis_learner$feature = factor(pfis_learner$feature, levels=pfis_learner$feature)

pfis = rbindlist(list(pfis_model, pfis_learner))

p_pfi = ggplot(pfis, aes(y = feature)) +
  geom_point(aes(x = pfi)) +
  geom_segment(aes(yend = feature, x = lower, xend = upper)) +
  scale_x_continuous("Feature Importance") +
  scale_y_discrete("") +
  facet_wrap('uqtype')

plot(p_pfi)
ggsave(sprintf("%s/pfi_application.pdf", fig_dir), width = 8, height = 3)


p_pfi_model = ggplot(pfis_model, aes(y = feature)) +
  geom_point(aes(x = pfi))+
  scale_x_continuous("Feature Importance") +
  scale_y_discrete("")

plot(p_pfi_model)
ggsave(sprintf("%s/pfi_model_application.pdf", fig_dir), width = 4, height = 2.5)


pdps$pdp
pdps_model = pdps[pdps$uqtype == 'model',]

p_pdp = ggplot(pdps_model, aes_string(x = 'feature')) +
  geom_line(aes(y = pdp)) + # + geom_point(aes(y=pdp))
  scale_y_continuous("PD") +
  scale_x_continuous("thalach")
plot(p_pdp)
ggsave(sprintf("%s/pdp_model_application.pdf", fig_dir), width = 4, height = 2.5)
