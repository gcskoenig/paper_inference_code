setwd('~/university/phd/2022/research/paper_inference/repos/iml-uq/')

library(ggplot2)
library(data.table)

feature = 'Age'
modelname = 'rf'
runpath = 'results/heartkaggle/run-1678899444/'
fimptype = 'diff'
fig_dir = runpath


fname = sprintf('%spdp/conditional/%s-%s.csv',
                runpath, modelname, feature)
df = read.csv(fname)

theme_set(theme_minimal() + theme(text = element_text(size = 10)))

pdps = df['pdp']
pdps['feature'] = df['xj']
pdps['upper'] = pdps['pdp'] + df['ci_delta']
pdps['lower'] = pdps['pdp'] - df['ci_delta']
pdps['uqtype'] = df['uqtype']

if (is.numeric(pdps$feature)) {
  p_pdp = ggplot(pdps, aes_string(x = 'feature')) +
    geom_line(aes(y = pdp)) +
    geom_line(aes(y = upper), lty = 2) + 
    geom_line(aes(y = lower), lty = 2) +
    scale_y_continuous("PD") +
    scale_x_continuous(feature) +
    facet_wrap('uqtype')
} else {
  p_pdp = ggplot(pdps, aes(x = feature)) +
    geom_point(aes(y = pdp)) +
    geom_segment(aes(xend=feature, y = lower, yend = upper)) +
    scale_y_continuous("PDP") +
    scale_x_discrete("") +
    facet_wrap('uqtype')
}

plot(p_pdp)
ggsave(sprintf("%s/%s-%s_pdp_application.pdf", fig_dir, modelname, feature),
       width = 8, height = 1.5)


df_pfi = read.csv(sprintf('%spfi/conditional/fis_brier-%s_%s.csv',
                          runpath, modelname, fimptype))

pfis = df_pfi['feature']
pfis['pfi'] = df_pfi['fi']
pfis['lower'] = df_pfi['fi'] - df_pfi['ci_delta']
pfis['upper'] = df_pfi['fi'] + df_pfi['ci_delta']
pfis['uqtype'] = df_pfi['uqtype']

pfis_model = pfis[pfis$uqtype == 'model',]
pfis_learner = pfis[pfis$uqtype == 'learner',]
ordering = order(pfis_learner$pfi)
pfis_model = pfis_model[ordering,]
pfis_learner = pfis_learner[ordering,]
pfis_model$feature = factor(pfis_model$feature, levels=pfis_model$feature)
pfis_learner$feature = factor(pfis_learner$feature, levels=pfis_learner$feature)

pfis = rbindlist(list(pfis_model, pfis_learner))

p_pfi = ggplot(pfis, aes(y = feature)) +
  geom_point(aes(x = pfi)) +
  geom_segment(aes(yend = feature, x = lower, xend = upper)) +
  scale_x_continuous("Feature Importance") +
  scale_y_discrete("") +
  facet_wrap('uqtype')

plot(p_pfi)
ggsave(sprintf("%s/pfi_%s_%s.pdf", fig_dir, modelname, fimptype),
       width = 8, height = 2)


p_pfi_model = ggplot(pfis_model, aes(y = feature)) +
  geom_point(aes(x = pfi))+
  scale_x_continuous("Feature Importance") +
  scale_y_discrete("")

plot(p_pfi_model)
ggsave(sprintf("%s/pfi_%s_%s_one_model.pdf", fig_dir, modelname, fimptype),
       width = 4, height = 2)


pdps$pdp
pdps_model = pdps[pdps$uqtype == 'model',]

p_pdp = ggplot(pdps_model, aes_string(x = 'feature')) +
  geom_line(aes(y = pdp)) + # + geom_point(aes(y=pdp))
  scale_y_continuous("PD") +
  scale_x_continuous(feature)
plot(p_pdp)
ggsave(sprintf("%s/pdp_%s_one_model.pdf", fig_dir, modelname),
       width = 4, height = 2)
