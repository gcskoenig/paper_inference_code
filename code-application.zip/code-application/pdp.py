import numpy as np
import pandas as pd


import seaborn as sns

from sklearn.base import clone
from scipy.stats import t

from tqdm import tqdm
import math
import argparse
from rfi.samplers import GaussianSampler
from sklearn.linear_model import LinearRegression
import multiprocess as mp

from sklearn.model_selection import train_test_split
from sklearn.base import is_classifier

def uqpdp(j, X, y, model, sampler, nr_refits, alpha, encoder,
          strategy='resampling', test_size=0.4,
          nr_samples=None, nr_grid_points=10,
          grid=None, uqtype='learner',
          sampling='conditional', refit_sampler=False):
    assert strategy == 'resampling'
    assert sampling in ['conditional', 'marginal']
    assert uqtype in ['model', 'learner']

    if nr_samples is None:
        nr_samples = X.shape[0]

    if uqtype == 'model':
        try:
            assert nr_refits == 1
        except Exception as exp:
            print(exp)
            nr_refits = 1

    if grid is None:
        # create quantile based grid
        if X.dtypes[j] == float or len(np.unique(X[j])) > nr_grid_points:
            min, max = 0.01, 0.99
            stepsize = (max - min) / nr_grid_points
            qgrid = np.arange(min, max - 0.0001, stepsize)
            grid = np.quantile(X[j], qgrid)
            assert len(grid) == nr_grid_points
        else:
            grid = np.unique(X[j])
    else:
        nr_grid_points = len(grid)

    pdps = np.zeros((nr_refits, len(grid), nr_samples))
    ns_train = np.zeros((nr_refits), dtype=int)
    ns_test = np.zeros((nr_refits), dtype=int)
    dd = 0
    for dd in range(nr_refits):
        model = clone(model)

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size)
        ns_test[dd], ns_train[dd] = X_test.shape[0], X_train.shape[0]
        X_train_enc = encoder.transform(X_train)
        model.fit(X_train_enc, y_train)
        R = list(set(X_train.columns) - {j})

        # mean_squared_error(y_test, model.predict(X_test))

        if sampling == 'conditional':
            if refit_sampler:
                sampler = sampler.copy()
                sampler.update_data(X_train)
            elif not sampler.is_trained(R, [j]):
                sampler.train(R, [j])

        gg = 0
        for gg in range(len(grid)):
            xj = grid[gg]
            if sampling == 'conditional':
                X_man = X.iloc[[0], :].copy()
                X_man.at[X_man.index[0], j] = xj
                X_C = sampler.sample(X_man, R, [j], num_samples=nr_samples)

                X_C[j] = xj
                X_xj = X_C[X_train.columns]
            else:  # marginal sampling
                X_xj = X.copy().sample(nr_samples, replace=False)
                X_xj[[j]] = xj
            X_xj_enc = encoder.transform(X_xj)
            if is_classifier(model):
                preds = model.predict_proba(X_xj_enc)[:, 1]
            else:
                preds = model.predict(X_xj_enc)
            #pdp_xj = np.mean(preds)
            pdps[dd, gg, :] = preds

    if uqtype == 'learner':
        pdps_agg = np.mean(pdps, axis=2)  # get rid of sample level
        pdps_mean = np.mean(pdps_agg, axis=0)
        pdps_var = np.var(pdps_agg, axis=0, ddof=1)
        adjustment = (1 / nr_refits) + (np.mean(ns_test) / np.mean(ns_train))
        pdps_var_adjusted = pdps_var * adjustment

        ci_delta = t.ppf(1 - (alpha/2), nr_refits - 1) * np.sqrt(pdps_var_adjusted)
    else:  # (if uqtype == 'model')
        assert pdps.shape[0] == 1
        pdps_agg = np.mean(pdps, axis=0)  # get rid of refits (should be only one)
        pdps_mean = np.mean(pdps_agg, axis=1)
        pdps_var = np.var(pdps_agg, axis=1, ddof=1)
        adjustment = (1 / nr_samples)
        pdps_var_adjusted = pdps_var * adjustment

        ci_delta = t.ppf(1 - (alpha/2), nr_samples - 1) * np.sqrt(pdps_var_adjusted)


    arrs = np.array([grid, pdps_mean, ci_delta, pdps_var, pdps_var_adjusted, np.repeat(uqtype, len(pdps_mean))]).T
    res = pd.DataFrame(data=arrs, columns=['xj', 'pdp', 'ci_delta', 'pdps_var', 'pdps_var_adjusted', 'uqtype'])

    return res


def in_interval(res):
    in_interval = np.logical_and(res['pdp'] - res['ci_delta'] <= res['dgp_pdp'],
                                 res['pdp'] + res['ci_delta'] >= res['dgp_pdp'])
    return in_interval


def plot_pdp(res, include_gt=False):
    types = ['pdp']
    if include_gt:
        types.append('dgp_pdp')
    df = res.copy()
    df = df[['xj'] + types]
    df = pd.melt(df, id_vars=['xj'])
    ax = sns.lineplot(data=df, x='xj', y='value', hue='variable')
    ax.fill_between(res.xj, res.pdp-res.ci_delta, res.pdp+res.ci_delta, alpha=0.2)
    return ax

# def experiment(N, nr_refits, grid, alpha, test_size, nr_samples, model, Sampler, sampling):
#     X, y = sample_linear_dgp(N)
#     sampler = Sampler(X)
#
#     res = uqpdp('x1', X, y, model, sampler, nr_refits, alpha,
#                 grid=grid,
#                 nr_samples=nr_samples,
#                 test_size=test_size,
#                 sampling=sampling)
#     res['dgp_pdp'] = res['xj']
#     in_intervals = in_interval(res)
#     return in_intervals, res
#
#
# if __name__ == '__main__':
#     parser = argparse.ArgumentParser()
#     parser.add_argument('--sampling', default='conditional', type=str)
#     args = parser.parse_args()
#
#     sampling = 'marginal'
#     sampling = args.sampling
#     print(f'Sampling strategy: {sampling}')
#     nr_refitss = [3, 5, 10, 15, 20, 30]
#     coverages = []
#     ci_sizess = []
#     for kk in range(len(nr_refitss)):
#         nr_refits = nr_refitss[kk]
#         print(f'nr_refits: {nr_refits}')
#         N = 1000
#         model = LinearRegression()
#         j = 'x1'
#         # nr_refits = 10
#         # nr_grid_points = 300
#         nr_samples = None
#         test_size = 1 - 0.632
#         alpha = 0.05
#         grid = [0.1, 0.3, 0.5, 0.7, 0.9]
#
#         nr_runs = 1000
#
#         experiment_cfg = lambda _: experiment(N, nr_refits, grid, alpha, test_size, nr_samples,
#                                               model, GaussianSampler, sampling)
#
#         pool = mp.Pool(processes=mp.cpu_count())
#         block_size = mp.cpu_count() * 2
#         blocks = math.floor(nr_runs / block_size)
#
#         in_intervalss = []
#         # ress = []
#         ci_sizes = []
#         for kk in tqdm(range(blocks)):
#             tmp = pool.map(experiment_cfg, np.arange(kk*block_size, (kk+1)*block_size, 1))
#             for ll in range(len(tmp)):
#                 in_intervalss.append(tmp[ll][0])
#                 # ress.append(tmp[ll][1])
#                 ci_sizes.append(tmp[ll][1]['ci_delta'].mean()*2)
#
#         in_intervalss = np.array(in_intervalss)
#         coverages.append(np.mean(in_intervalss))
#         ci_sizess.append(np.mean(ci_sizes))
#
#     print('compiling coverages')
#
#     coverages = np.array(coverages)
#     nr_refitss = np.array(nr_refitss)
#     ci_sizess = np.array(ci_sizess)
#
#     print('saving coverages')
#
#     arrs = np.array([nr_refitss, coverages, ci_sizess]).T
#     df = pd.DataFrame(data=arrs, columns=['nr_refits', 'coverage', 'ci_size'])
#     df.to_csv(f'coverages_{sampling}.csv')
#
#     print('donesaving coverages')