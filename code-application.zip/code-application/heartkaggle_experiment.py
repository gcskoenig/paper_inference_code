import sys
import os
sys.path.append(os.getcwd())

import pandas as pd
from application.loaders.loadheartkaggle import *
from pathlib import Path
import time

X, y = get_data()
sampler = get_sampler(X)
models = get_models()
scores = get_scores()

cont_features = [col for col in X.columns if col not in sampler.categorical_fs]

encoder = get_encoder()
nr_refits = 15
alpha = 0.05
nr_grid_points = 10
test_size = 0.4

from src.pdp import *
from src.pfi import *

runid = int(math.floor(time.time()))

basepath = f"results/heartkaggle/run-{runid}/"
Path(basepath).mkdir(parents=True, exist_ok=True)

# get and store model performances



uqtype = 'model'
sampletype = 'marginal'
for sampletype in ['conditional', 'marginal']:
    pfipath = basepath + f'pfi/{sampletype}/'
    Path(pfipath).mkdir(parents=True, exist_ok=True)
    pdppath = basepath + f'pdp/{sampletype}/'
    Path(pdppath).mkdir(parents=True, exist_ok=True)

    mname = 'rf'
    for mname in models.keys(): #range(len(models)):
        print(f'model: {mname}')

        key = list(scores.keys())[0]
        for key in scores.keys():
            print(f'computing {key}-based {uqtype}-fi with {sampletype} sampling (model {mname})')
            res_props = pd.DataFrame()
            res_diffs = pd.DataFrame()
            perfss = pd.DataFrame()
            uqtype='model'
            for uqtype in ['model', 'learner']:
                (res_prop, res_diff), perfs = uqpfi(X, y, models[mname], sampler, nr_refits, alpha, scores[key][0], encoder,
                                       uqtype=uqtype,
                                       strategy='resampling', test_size=test_size,
                                       sampling=sampletype, smaller_better=scores[key][1])
                res_props = pd.concat([res_props, res_prop])
                res_diffs = pd.concat([res_diffs, res_diff])
                perfss = pd.concat([perfss, perfs])

            perfss.to_csv(pfipath + f'perfs_{key}-{mname}.csv')
            res_props.to_csv(pfipath + f'fis_{key}-{mname}_prop.csv')
            res_diffs.to_csv(pfipath + f'fis_{key}-{mname}_diff.csv')

        j = cont_features[0]
        for j in cont_features:
            res_pdps = pd.DataFrame()
            for uqtype in ['model', 'learner']:
                print(f'computing {uqtype}-pdp with {sampletype} sampling for model {mname} feature {j}')
                res_pdp = uqpdp(j, X, y, models[mname], sampler, nr_refits, alpha, encoder,
                                strategy='resampling', test_size=test_size,
                                nr_grid_points=nr_grid_points, sampling=sampletype, uqtype=uqtype)
                res_pdps = pd.concat([res_pdps, res_pdp])
            res_pdps.to_csv(pdppath + f'{mname}-{j}.csv')