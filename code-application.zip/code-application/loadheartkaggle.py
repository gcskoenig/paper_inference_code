# https://www.kaggle.com/datasets/fedesoriano/heart-failure-prediction

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, brier_score_loss, confusion_matrix, make_scorer, accuracy_score
from sklearn.model_selection import train_test_split, cross_val_score

from rfi.samplers import SequentialSampler, UnivRFSampler, ContUnivRFSampler
import category_encoders as ce
from rfi.explainers import Explainer


def get_data(return_df=False):
    df = pd.read_csv('heart.csv', sep=',')
    df['Sex'] = df['Sex'].astype('category')
    df['ChestPainType'] = df['ChestPainType'].astype('category')
    df['RestingECG'] = df['RestingECG'].astype('category')
    df['ExerciseAngina'] = df['ExerciseAngina'].astype('category')
    df['ST_Slope'] = df['ST_Slope'].astype('category')

    if return_df:
        return df
    else:
        y_label = 'HeartDisease'
        drop = []
        not_in_X = [y_label] + drop

        X = df[df.columns[~df.columns.isin(not_in_X)]]
        y = df[y_label]
        return X, y


def pairplot_data():
    df = get_data(return_df=True)
    sns.pairplot(df)
    plt.savefig('heartfailure_pairplot.pdf')


def get_models():
    rf = RandomForestClassifier()
    # lm = LogisticRegression(penalty='elasticnet', solver='saga', l1_ratio=0.9)
    lm = make_pipeline(StandardScaler(), LogisticRegression())
    dt = DecisionTreeClassifier()
    models = {'lm': lm, 'dt': dt, 'rf': rf}
    return models


def get_sampler(X_train):
    X, y = get_data()
    cat_features = X.select_dtypes(exclude=[float, int]).columns

    cat_sampler = UnivRFSampler(X_train, cat_inputs=cat_features)
    cont_sampler = ContUnivRFSampler(X_train, cat_inputs=cat_features)
    seq_sampler = SequentialSampler(X_train, categorical_fs=cat_features,
                                    cat_sampler=cat_sampler,
                                    cont_sampler=cont_sampler)

    return seq_sampler


def get_scorers():
    # auc_scorer = make_scorer(roc_auc_score, needs_proba=True)
    # auc_loss = lambda *args, **kwargs: 1 - auc_scorer(*args, **kwargs)
    # scorers = {'auc_loss': (auc_loss, True)}
    scores = get_scores()
    scorers = {}
    for key in scores.keys():
        score, needs_proba, smaller_better = scores[key]
        scorers[key] = (make_scorer(score, needs_proba=needs_proba), smaller_better)
    return scorers


def get_scores():
    scores = {'brier': (brier_score_loss, True, True)}
    return scores


def get_encoder():
    X, y = get_data()
    encoder = ce.OneHotEncoder()
    encoder.fit(X)
    return encoder


if __name__ == '__main__':
    # pairplot_data()

    X, y = get_data()
    enc = ce.OneHotEncoder(X)
    enc.fit(X)
    X_enc = enc.transform(X)
    models = get_models()
    scorers = get_scorers()

    model = models['rf']
    # scorer = make_scorer(brier_score_loss)
    perfs = pd.DataFrame()
    for mname in models.keys():
        perfs[mname] = list(cross_val_score(models[mname], X_enc, y, cv=5, scoring=scorers['brier'][0]))
        print(f'mean cross val score of {mname}: {np.mean(perfs[mname])}')

    perfs.to_csv('heartkaggle-brier-perfs.csv')
    perfs.mean().to_csv('heartkaggle-brier-perfs-mean.csv')

    for mname in models.keys():
        print(type(model))
        model = models[mname]
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3)
        X_train_enc = enc.transform(X_train)
        model.fit(X_train_enc, y_train)

        X_test_enc = enc.transform(X_test)
        print(brier_score_loss(y_test, model.predict(X_test_enc)))
        print(confusion_matrix(y_test, model.predict(X_test_enc)))

        sampler = get_sampler(X_train)

        wrk = Explainer(model.predict, X.columns, X_train, sampler=sampler, loss=brier_score_loss, encoder=enc)
        ex = wrk.dis_from_baselinefunc(X_train.columns, X_test, y_test)
        ex.hbarplot()
        plt.show()

        ex = wrk.ais_via_contextfunc(X_train.columns, X_test, y_test)
        ex.hbarplot()
        plt.show()
