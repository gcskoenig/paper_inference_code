import numpy as np
import pandas as pd

from sklearn.base import clone
from scipy.stats import t

from sklearn.model_selection import train_test_split
from sklearn.base import is_classifier

def get_instancewise_fnc(score):
    lbd_f = lambda y_true, p_pred : score([y_true], [p_pred])
    f = np.vectorize(lbd_f)
    return f


def compile_uq_band(fis, alpha, fs_names, uqtype, n_train):
    n_eval, nr_refits, n_cols = fis.shape

    if uqtype == 'learner':
        # transform to array with nr_refits, nr_columns
        fis_agg = np.mean(fis, axis=0)  # aggregate over the samples

        # perform usual computations
        fis_mean = np.mean(fis_agg, axis=0)  # aggregate over refits
        fis_var = np.var(fis_agg, axis=0, ddof=1)  # variance over refits
        adjustment = (1 / nr_refits) + (n_eval / n_train)  # nadio bengio adjustment
        fis_var_adjusted = fis_var * adjustment  # apply adjustment
        ci_delta = t.ppf(1 - (alpha / 2), nr_refits - 1) * np.sqrt(fis_var_adjusted)
    else:  # uqtype == 'model'
        fis_agg = np.mean(fis, axis=1)
        fis_mean = np.mean(fis, axis=0).flatten()
        fis_var = np.var(fis_agg, axis=0, ddof=1).flatten()
        fis_var_adjusted = fis_var * (1 / n_eval)
        ci_delta = t.ppf(1 - (alpha / 2), n_eval - 1) * np.sqrt(fis_var_adjusted)

    arrs = np.array([fs_names, fis_mean, ci_delta, fis_var, fis_var_adjusted, np.repeat(uqtype, len(fis_mean))]).T
    res = pd.DataFrame(data=arrs, columns=['feature', 'fi', 'ci_delta', 'fis_var', 'fis_var_adjusted', 'uqtype'])
    res = res.sort_values(by='fi', ascending=False)
    return res


def uqpfi(X, y, model, sampler, nr_refits, alpha, score, encoder,
          strategy='resampling', test_size=0.3,
          sampling='conditional', refit_sampler=False, smaller_better=True,
          uqtype='learner', nr_samples=1):
    assert strategy == 'resampling'
    assert sampling in ['conditional', 'marginal']
    assert nr_samples == 1
    if uqtype == 'model':
        try:
            assert nr_refits == 1
        except Exception as exp:
            print(exp)
            nr_refits = 1
        assert not refit_sampler

    scoref = get_instancewise_fnc(score)

    # set all data as default for sampler training
    sampler = sampler.copy()
    sampler.update_data(X)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size)
    n_train, n_eval = X_train.shape[0], X_test.shape[0]
    fis_prop = np.zeros((n_eval, nr_refits, len(X.columns)))
    fis_diff = np.zeros((n_eval, nr_refits, len(X.columns)))
    perf = np.zeros((n_eval, nr_refits))

    dd = 0
    for dd in range(nr_refits):

        model = clone(model)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size)
        assert X_test.shape[0] == n_eval and X_train.shape[0] == n_train
        X_train_enc = encoder.transform(X_train)
        model.fit(X_train_enc, y_train)

        X_test_enc = encoder.transform(X_test)
        if is_classifier(model):
            score_before = scoref(y_test, model.predict_proba(X_test_enc)[:, 1])
        else:
            score_before = scoref(y_test, model.predict(X_test_enc))
        perf[:, dd] = score_before

        jj = 0
        for jj in range(len(X.columns)):
            j = X.columns[jj]
            R = list(set(X_train.columns) - {j})

            # sampling perturbation
            if sampling == 'conditional':
                if refit_sampler:
                    sampler = sampler.copy()
                    sampler.update_data(X_train)
                elif not sampler.is_trained([j], R):
                    # is trained on the whole datast if it was not trained already
                    sampler.train([j], R)

                x_j_man = sampler.sample(X_test, [j], R, num_samples=1)
                X_test_man = X_test.copy()
                X_test_man[j] = np.array(x_j_man)
                X_test_man = X_test_man[X_train.columns]
            else:  # marginal sampling
                X_test_man = X_test.copy()
                X_test_man[j] = np.random.permutation(X_test[j])

            # prediction and performance
            X_test_man_enc = encoder.transform(X_test_man)
            if is_classifier(model):
                scores = scoref(y_test, model.predict_proba(X_test_man_enc)[:, 1])
            else:
                scores = scoref(y_test, model.predict(X_test_man_enc))
            prop = score_before / scores  # case where smaller better
            diff = scores - score_before
            if smaller_better:
                fis_prop[:, dd, jj] = prop
                fis_diff[:, dd, jj] = diff
            else:
                fis_prop[:, dd, jj] = 1 / prop
                fis_diff[:, dd, jj] = -diff

    res_prop = compile_uq_band(fis_prop, alpha, X.columns, uqtype, n_train)
    res_diff = compile_uq_band(fis_diff, alpha, X.columns, uqtype, n_train)
    perfs = pd.DataFrame(data=np.array([np.mean(perf, axis=0), np.arange(nr_refits)]).T, columns=['model_performance', 'fit'])

    return (res_prop, res_diff), perfs


def plot_pfis(res):
    # idea: https://stackoverflow.com/questions/30385975/seaborn-factor-plot-custom-error-bars-instead-of-bootstrapping
    pass


if __name__ == '__main__':
    from loadheartdisease import get_data, get_models, get_scorer, get_sampler, get_encoder

    X, y = get_data()
    models = get_models()
    scorer = get_scorer()
    sampler = get_sampler(X)
    encoder = get_encoder()

    model = models[1]
    nr_refits = 10
    alpha = 0.05
    strategy = 'bootstrap'
    test_size = 0.3
    sampling = 'conditional'
    uqtype = 'model'

    uqpfi(X, y, models[0], sampler, nr_refits, alpha, scorer, encoder,
          strategy=strategy, test_size=test_size, sampling=sampling,
          uqtype=uqtype)
