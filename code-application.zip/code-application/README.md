# Installation

In order to run the scripts a current version of R and of python must be installed. (Date of writing the README: 22-11-29)
Furthermore, the python code depends on a python package (rfi) which is not available via pip.

In order to run the code, first install the rfi package following the instructions in the corresponding README.

Then run heartdisease_experiment.py.

Last, you can run "plots.R" to visualize the results. In order to plot your own results, the path to the csv must be adapted.

