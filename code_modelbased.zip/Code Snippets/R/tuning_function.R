#Tuning Functions ----
#For random forests and Gaussian process 


#' Basic Hyperparamter tuning using K-Fold cross validation for the Gaussian process and subsampled random forest as well as random search for the 
#' ranger random forest. 
#'
#' @param dgp a DGP defined in the same fashion as the ones in DGPs.R, input is the function generating the data. 
#' @param param_grid parameter grid specifiying the possible hyperparameters. Compare e.g. the param_grid defined in hyperparameter_tuning.R 
#' @param mod either c("rf_sub", "km", "rf_ranger")
#' @param n number of samples drawn from DGP
#' @param task either c("regression", "classification") for regression mse is used as measure for classification accuracy, 
#' classification only implemented for rf_sub 
#' @param cv_folds number of folds for cross validation
#' @param ... additional parameters for the DGP 
#'
#' @return
#' @export
#'
#' @examples
tune_hyperparams <- function(dgp, param_grid, mod, n = 1000, task = "regression", cv_folds = 5, ...){
  set.seed(1)
  data <- dgp(n, ...)  
  cores <- set_cores(os_type =  .Platform$OS.type)
  matched_task <- match.arg(task, c("regression", "classification"))
    if (mod == "km"){
      #k-fold cross-validation potentially in parallel
      rmses <- mclapply(1:nrow(param_grid), mc.cores = cores, function(i){
        params <- param_grid[i,]
        vals <- c()
        if (cv_folds > 1){
          folds <- cut(seq(1,nrow(data)),breaks=cv_folds,labels=FALSE)
        } else {
          #if only one fold then automatically 50:50 train test split 
          folds <- cut(seq(1,nrow(data)),breaks=cv_folds+1,labels=FALSE)
        }
        for (j in 1:cv_folds){
          set.seed(1)
          test_indices <- which(folds==j,arr.ind=TRUE)
          dt_test <- data[test_indices, ]
          dt_train <- data[-test_indices, ]
          #tryCatch necessary since some models can throw error 
          model <- tryCatch({
            purrr::pmap(params, ~ km(formula = ~1, design = dt_train[,-c("y")], response = dt_train$y, ...)) #covtype 
          }, 
          error = function(cond){
            return(NULL)
          })
          if (is.null(model)){
          vals <- append(vals, NA)
          } else {
            fitted_model <- model[[1]]
            preds <- predict(object = fitted_model, newdata = dt_test[,-c("y")], type = "SK")
            f_hat <- preds$mean
            rmse <- compute_rmse(dt_test$y, f_hat)
            vals <- append(vals, rmse)
          }  
        }
        return(mean(vals))
      })
    } else {
      stop("Not implemented for this model.")
    }
    
    #determine minimal mse and return results 
    min_rmse <- which.min(rmses)
    minimizer <- param_grid[min_rmse, ]
    rmses <- unlist(rmses)
    
    return(list(values = rmses, winning_config = minimizer)) 
  
}


