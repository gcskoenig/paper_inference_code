#!/usr/bin/Rscript
#create object which stores important information on the PDP

pd_full_cov <- R6::R6Class("pd-full-cov",
                           public = list(
                             type = NULL,
                             features = NULL,
                             grid_points = NULL, 
                             response_func = NULL, 
                             target = NULL,
                             os_type = .Platform$OS.type,
                             implemented_models = list("lm" = pdp_lm_freq, "gam" = pdp_am_freq, "km" = pdp_gp, "rf_sub" = pdp_rf_sub, 
                                                       "rf_ranger" = pdp_rf_ranger, "nn" = pdp_nn),
                             
                             
#' Title
#'
#' @param type indicating name of model to refer to a function in confint_functions.R. If model should be added, add to the list called 
#' "implemented_models" in class pd_full_cov.
#' @param features vector of strings indicating for which features of a dataset the PDP should be computed. Default is "all" which calculates PDP 
#' for all features but using the same grid. 
#' @param grid_points vector of grid points. Default is c(0.1, 0.2, ..., 0.9).
#' @param response_func response function for. Default is identity. 
#' @param target string indicating name of target variable. Default is "y". 
#'
#' @return partial dependence function evaluated at grid points together with point-wise confidence bands over PD.  
#' @export
#'
#' @examples
                             initialize = function(type, features = "all", grid_points = seq(0.1, 0.9, by=0.1), response_func = identity, target = "y"){
                               self$type = type #c("lm", "gam", "km", "rf", "rf_ranger", "nn")
                               self$features = features 
                               self$grid_points = grid_points 
                               self$response_func = response_func
                               self$target = target 
                             }, 
                             #method for calculating pdp given a fitted model and a dataset 
                             calc_pdp = function(model, data, level = 0.95){
                              
                               cores <- set_cores(self$os_type)
                               
                               fitted_model <- extract_fitted_model(model)
                               
                               #for all features by default 
                               #all_features <- setdiff(colnames(data), self$target)
                               if (self$features == "all"){
                                 features <- setdiff(colnames(data), self$target)
                               } else {
                                 features <- self$features
                               }
                               
                               #data <- data[, mget(all_features)]
                               
                               #models method can handle  
                               
                               type <- match.arg(self$type, c("lm", "gam", "km", "rf_sub", "rf_ranger", "nn"))
                               
                               ci_function <- self$implemented_models[[type]]
                               
                              #each variable of each dgp will have the same grid points by convention
                               all_confints <- rbindlist(lapply(features, function(i) {
                                
                                confints <- ci_function(feature = i, fitted_model = fitted_model, data = data, 
                                                        grid = self$grid_points, level = level)  
                                
                              }))
                              setnames(all_confints, c("grid_point", "pdp", "se", "lower_bound", "upper_bound", "feature", "mc_sd"))
                              all_confints[, width := upper_bound - lower_bound]
                              return(all_confints)
                                                           
                             }
                             
  )
)
