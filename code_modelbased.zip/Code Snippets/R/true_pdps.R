#True PDPs 
#analytical calculation of true pdp for all variables of dgp_linear_simple
true_pdp_dgp_linear_simple <- function(){
  features <- colnames(dgp_linear_simple(2)[,-c("y")])
  grid_points <- seq(0.1, 0.9, 0.2)
  expected_values <- data.table()
  #true_pdps <- CJ(features = features, grid_point = grid_points)
  for (feature in features){
    expected_values[, paste(feature) := 0.5]
  }
  coefficients <- c(4,-2,2,-1,1)
  true_pdps <- rbindlist(lapply(features, function(feature) {
    #if uniform distribution on the interval [0,1] is used 
    base_table <- do.call("rbind", replicate(length(grid_points), expected_values, simplify = FALSE))
    exp_matrix <- as.matrix(base_table[, eval(feature) := grid_points])
    true_vals <- exp_matrix %*% coefficients
    tab <- data.table(feature = feature, grid_point = grid_points)
    tab[ ,true_pdp := true_vals]
    return(tab)
  }))
  return(true_pdps)
}


#For cases where analytical calculation is more difficult and there exists a consistent or unbiased estimator of the DGP-PD 
#we can determine the true value by calculating the average over many PD estimates calculated by repeatedly drawing of a large number 
#of observations and calculating the PDP 
#' Title
#'
#' @param model_wrapper function taking data and returning a trained model (see for example retrieve_results_general.R)
#' @param dgp DGP as defined in DGPs.R
#' @param pdp_class one of the three pd_classes in pdp_classes.R
#' @param n number of samples to be used (0.632n will be used for training, 0.368n for fitting PDP)
#' @param reps number of repetitions. Determines how many times PDP will be computed. 
#' @param ... additional arguments for DGP 
#'
#' @return estimate of true partial dependence which will be an estimate for the to DGP-PD if model is unbiased 
#' @export
#'
#' @examples
true_pdp <- function(model_wrapper, dgp, pdp_class, n = 5000, reps = 10000, ...){
  cores <- set_cores(.Platform$OS.type)
  pdps <- rbindlist(mclapply(1:reps, mc.cores = cores, function(i) {
    set.seed(i)
    data <- dgp(n, ...)
    train_indices <- sample(1:n, size = floor(0.632*n), replace = FALSE)
    dt_train <- data[train_indices,]
    dt_test <- data[-train_indices,]
    model <- model_wrapper(dt_train)
    if (pdp_class$type %in% c("km", "rf")){
      pdp <- pdp_class$calc_pdp(model$fitted_model, dt_test[,-c("y")])  
    } else {
      pdp <- pdp_class$calc_pdp(model$fitted_model, dt_test)  
    }
    if (i%%100 == 0){
      print(paste("Iteration", i))
    }
    return(pdp)
  }))
  
  mean_pdp <- as.data.table(pdps %>% group_by(feature, grid_point) %>% summarize(true_pdp = mean(pdp)))
  mean_pdp[, true_pdp_diff := c(NA, diff(true_pdp)), by = "feature"]
  
  return(mean_pdp)
}
