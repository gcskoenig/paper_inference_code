#!/usr/bin/Rscript
# Model Wrapper ----
#fit model and calculate PDP
#hyperparameter tuning is performed separately beforehand 
#define experiment once in pdp_class and then use calc_pdp of same pdp_object for multiple models 

#' wrapper for computing model-based confidence intervals following the logic of an batchtools algorithm 
#'
#' @param model model wrapper with same return values as the wrappers defined in experiments_<name>.R scripts 
#'
#' @return calculated partial dependence function with model-based credible / confidence bands 
#' @export
#'
#' @examples
modelbased_wrapper <- function(model){
  #Follows the logic of algorithm in batchtools 
  model_pd <- function(data, job, instance, ...){
    dt <- instance$dt
    cor <- instance$rho
    n <- nrow(dt)
    train_indices <- sample(1:nrow(dt), size = floor(job$prob.pars$train_size*nrow(dt)), replace = FALSE)
    dt_train <- dt[train_indices, ]
    dt_test <- dt[-train_indices, ]
    grids <- list("a" = seq(0.1,0.9,0.2), "b" = seq(0.1,0.9,0.1))
    grid <- grids[[job$prob.pars$grid]]
    #in case train_size = 1
    if (nrow(dt_test) == 0){
      dt_test <- dt_train
    }
    
    fitted_model <- model(dt_train, dt_test)
    pdp_class <- fitted_model$pdp_class
    if (pdp_class == "bayes"){
      pdp_obj = pd_bayes$new(features = job$prob.pars$features, grid_points = grid)
    } else if (pdp_class == "full_cov"){
      pdp_obj = pd_full_cov$new(fitted_model$type, features = job$prob.pars$features, grid_points = grid)
    } else if (pdp_class == "bayes_diff"){
      pdp_obj = pd_bayes_diff$new(features = job$prob.pars$features, grid_points = grid)
    } else {
      stop("Class not defined.")
    }
  
    if (fitted_model$type %in% c("km", "rf")){
      pdps <- pdp_obj$calc_pdp(fitted_model$fitted_model, dt_test[,-c("y")])  
    } else {
      pdps <- pdp_obj$calc_pdp(fitted_model$fitted_model, dt_test)  
    }
    
    pdps[, "version" := paste0(fitted_model$type)]
    pdps[, "n" := n]
    pdps[, "test_loss" := fitted_model$loss]
    if (!is.null(cor)){
      pdps[, "cor" := cor]
    }
    return(pdps)
}
}