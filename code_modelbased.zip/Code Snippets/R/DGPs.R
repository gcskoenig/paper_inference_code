#DGP 1
dgp_linear_simple <- function(n, distr = "uniform"){
  distr <- match.arg(distr, c("normal", "uniform"))
  if (distr == "uniform"){
    for (i in 1:5){
      name <- paste0("x",i)
      assign(name, runif(n, 0, 1))
    }
  } else if (distr == "normal"){
    for (i in 1:5){
      name <- paste0("x",i)
      assign(name, rnorm(n, 0, 1))
    }
  } else {
    stop("Unknown distribution.")
  }
  
  f <- 4*x1 - 2*x2 + 2*x3 - x4 + x5  
  y <- f + rnorm(n, 0, sd(f)*0.2)
  
  dt <- data.table(y = y, x1 = x1, x2 = x2, x3 = x3, x4 = x4, x5 = x5)
  return(dt)
}

gen_linear_simple <- function(data, job, n, distr, ...){
  dt <- dgp_linear_simple(n, distr)
  return(list("dt" = dt, name = "dgp_linear_simple", "n" = n, "distr" = distr))
}



#DGP 2
dgp_nonlinear_simple <- function(n, distr = "uniform"){
  distr <- match.arg(distr, c("normal", "uniform"))
  if (distr == "uniform"){
    for (i in 1:5){
      name <- paste0("x",i)
      assign(name, runif(n, 0, 1))
    }
  } else if (distr == "normal"){
    for (i in 1:5){
      name <- paste0("x",i)
      assign(name, rnorm(n, 0, 1))
    }
  } else {
    stop("Unknown distribution.")
  }
  
  f <- 2*sin(2*pi*x1) + cos(2*pi*x2) + exp(0.5*x3) - 2*x4^2 + sqrt(x5) 
  y <- f + rnorm(n, 0, sd(f)*0.2)
  
  dt <- data.table(y = y, x1 = x1, x2 = x2, x3 = x3, x4 = x4, x5 = x5)
  return(dt)
}

gen_nonlinear_simple <- function(data, job, n, distr, ...){
  dt <- dgp_nonlinear_simple(n, distr)
  return(list("dt" = dt, name = "dgp_nonlinear_simple", "n" = n, "distr" = distr))
}