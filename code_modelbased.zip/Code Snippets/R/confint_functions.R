#!/usr/bin/Rscript
#Functions for generating confidence intervals for PDPs using the full covariance matrix 
#Functions are used in class pd_full_cov

#Linear Model ----
#Frequentist version for method pdp_calc in pd_full_cov
#' Calculate Frequentist version of confidence bands for PD with linear model 
#'
#' @param feature string indicating feature for wich to calculate PD
#' @param fitted_model fitted stats::lm model 
#' @param data data.table containing dataset on which to calculate PD 
#' @param grid vector of grid points for which to calculate PD
#' @param level confidence level for interval, default is 0.95  
#'
#' @return data.table with calculated CI and PD per grid point 
#' @export
#'
#' @examples
pdp_lm_freq <- function(feature, fitted_model, data, grid, level = 0.95){
  data <- as.data.table(data)
  q <- abs(qnorm((1-level)/2))
  n <- nrow(data)
  params <- coef(fitted_model)
  cov <- vcov(fitted_model)
  
  std_pdp <- rbindlist(lapply(grid, function(x) {
    data[, feature] <- x
    design_matrix <- model.matrix(formula(fitted_model$call$formula), data)
    
    #variance of mean 
    ices <- design_matrix %*% params
    pdp <- mean(ices)
    var <- (1/n^2) * sum(design_matrix %*% cov %*% base::t(design_matrix))   
  
    se <- sqrt(var)
    
    #calculate Monte Carlo error according to Molnar et al. (2021)
    mc_sd <- sqrt((1/n)*var(ices))
    
    return(data.table(grid_point = x, pdp = pdp, se = se, lower_bound = pdp - q * se, upper_bound = pdp + q * se, feature = feature, mc_sd = mc_sd))
    
  }))
  return(std_pdp)
}



#Gaussian Process ----
#' Calculate credible band for Gaussian process 
#'
#' @param feature string indicating feature for wich to calculate PD 
#' @param fitted_model fitted DiceKriging:km GP model
#' @param data data.table containing dataset on which to calculate PD 
#' @param grid vector of grid points for which to calculate PD
#' @param level confidence level for interval, default is 0.95 
#'
#' @return data.table with calculated CI and PD per grid point 
#' @export
#'
#' @examples
pdp_gp <- function(feature, fitted_model, data, grid, level = 0.95){
  #takes km() regressor from package DiceKriging 
  data <- as.data.table(data)
  q <- abs(qnorm((1-level)/2))
  n <- nrow(data)
  
  std_pdp <- rbindlist(lapply(grid, function(x) {
    
    data[, feature] <- x
    #analogue to Moosbauer et al. (2021)
    pred <- predict(object = fitted_model, newdata = data, type = "SK", cov.compute = TRUE)
    #ICEs 
    ices <- pred$mean 
    #PDP
    pdp <- mean(ices)
    var <- (1/n^2)*sum(pred$cov)
    se <- sqrt(var)
    
    mc_sd <- sqrt((1/n)*var(ices))
    return(data.table(grid_point = x, pdp = pdp, se = se, lower_bound = pdp - q * se, upper_bound = pdp + q * se, feature = feature, mc_sd = mc_sd))
  }))
  
 return(std_pdp)       
}
