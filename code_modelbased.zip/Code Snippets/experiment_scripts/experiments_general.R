#!/usr/bin/Rscript
library(data.table)
library(plyr)
library(dplyr)
library(keras)
library(tensorflow)
library(tfprobability)
library(surfin)
library(DiceKriging)
library(mgcv)
library(parallel)
library(batchtools)
library(MASS)
library(stringr)
library(ranger)


## Define model wrappers 
lm_wrapper <- function(pdp_class, linear_data = TRUE){
  lm_mod <- function(data, test_data){
    if (linear_data){
      model <- lm(y~., data = data)
    } else {
      model <- lm(y~sin(2*pi*x1) + cos(2*pi*x2) + exp(0.5*x3) + I(x4^2) + sqrt(x5), data = data)  
    }
    preds <- predict.lm(model, newdata = test_data)
    rmse <- compute_rmse(test_data$y, preds)
    return(list("fitted_model" = model, "type" = "lm", "pdp_class" = pdp_class, "loss" = rmse))
  }
}

lm_mod_lin <- lm_wrapper("full_cov", TRUE)
lm_mod_nonlin <- lm_wrapper("full_cov", FALSE)


#hyperparameters can be found in script "hyperparameter_tuning.R"
km_mod_lin <- function(data, test_data){
  model <- km(formula = ~1, design = data[,-c("y")], response = data$y, covtype = "powexp")
  preds <- predict.km(model, newdata = test_data[,-c("y")] ,type = "SK")
  rmse <- compute_rmse(test_data$y, preds$mean)
  return(list("fitted_model" = model, "type" = "km", "pdp_class" = "full_cov", "loss" = rmse))
}

#hyperparameters can be found in script "hyperparameter_tuning.R"
km_mod_nonlin <- function(data, test_data){
  model <- km(formula = ~1, design = data[,-c("y")], response = data$y, covtype = "exp")
  preds <- predict.km(model, newdata = test_data[,-c("y")] ,type = "SK")
  rmse <- compute_rmse(test_data$y, preds$mean)
  return(list("fitted_model" = model, "type" = "km", "pdp_class" = "full_cov", "loss" = rmse))
}

## dgp_linear_simple, model based coverage ----
if (file.exists("registry_general_lin")){
  reg <- loadRegistry("./registry_general_lin", writeable = TRUE)
} else{
  reg <- makeExperimentRegistry("./registry_general_lin")
}

reg$cluster.functions = makeClusterFunctionsMulticore()

addProblem(name = "dgp_linear_simple", data = data.table(), fun = gen_linear_simple, seed = 1)

algo1_mb <- modelbased_wrapper(lm_mod_lin)
addAlgorithm("lm_mod", algo1_mb)


algo2_mb <- modelbased_wrapper(km_mod_lin)
addAlgorithm("km_mod_lin", algo2_mb)

pdes <- list("dgp_linear_simple" = CJ(n = c(200, 1000), train_size = 0.632, dist = "uniform", features = "all", grid = "a"))
addExperiments(pdes, repls = 1000)

submitJobs()
getStatus()

waitForJobs()

## dgp_nonlinear_simple, model based coverage ----
if (file.exists("registry_general_nonlin")){
  reg <- loadRegistry("./registry_general_nonlin", writeable = TRUE)
} else{
  reg <- makeExperimentRegistry("./registry_general_nonlin")
}


reg$cluster.functions = makeClusterFunctionsMulticore()
#reg$cluster.functions = makeClusterFunctionsInteractive()


addProblem(name = "dgp_nonlinear_simple", data = data.table(), fun = gen_nonlinear_simple, seed = 1)

algo1_mb <- modelbased_wrapper(lm_mod_nonlin)
addAlgorithm("lm_mod", algo1_mb)

algo2_mb <- modelbased_wrapper(km_mod_nonlin)
addAlgorithm("km_mod_nonlin", algo2_mb)

pdes <- list("dgp_nonlinear_simple" = CJ(n = c(200, 1000), train_size = 0.632, dist = "uniform", features = "all", grid = "a"))
addExperiments(pdes, repls = 1000)

submitJobs()
getStatus()

waitForJobs()
