# #Hyperparameter tuning on respective datasets for Gaussian Process
library(DiceKriging)
library(data.table)
library(parallel)
library(MASS)
library(purrr)


# Define the parameter grids for the experiments ----
#for simple linear data (dgp_linear_cor() with rho = 0)
#Gaussian Process
configs_km_basic <- data.table(covtype = c("gauss", "powexp", "exp", "matern5_2", "matern3_2"))

###############################################################################################################
# Tuning models for basic average coverage simulations (script experiments_general.R) ----
################################################################################################################

#For BNN tuning with Optuna see Python script bnn_tuning.py 
#Gaussian process / kriging model
pars_km_linear <- tune_hyperparams(dgp = dgp_linear_simple, param_grid = configs_km_basic, mod = "km", n = 1000)
# > pars_km_linear
# $values
# [1] 0.5368665 0.3569326 0.3714511 0.4694533 0.4360993
# 
# $winning_config
# covtype
# 1:  powexp

pars_km_nonlinear <- tune_hyperparams(dgp = dgp_nonlinear_simple, param_grid = configs_km_basic, mod = "km", n = 1000)
# > pars_km_nonlinear
# $values
# [1] 1.0875597 0.4330070 0.4313175 0.5218631 0.4986188
# 
# $winning_config
# covtype
# 1:     exp