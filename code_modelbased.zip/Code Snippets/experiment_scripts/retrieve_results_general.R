#!/usr/bin/Rscript
library(data.table)
library(plyr)
library(dplyr)
library(keras)
library(tensorflow)
library(tfprobability)
library(surfin)
library(DiceKriging)
library(mgcv)
library(parallel)
library(batchtools)
library(MASS)
library(stringr)
library(xtable)


## Define true PDPs ----
#Linear Model (dgp_linear_simple)
true_pdp_linear <- true_pdp_dgp_linear_simple()


#Nonlinear Model (gp_nonlinear_simple)
true_mod <- function(data){
  mod <- lm(y ~ sin(2*pi*x1) + cos(2*pi*x2) + exp(0.5*x3) + I(x4^2) + sqrt(x5), data = data)
  return(list("fitted_model" = mod))
}
true_pdp_nonlinear <- true_pdp(model_wrapper = true_mod, dgp = dgp_nonlinear_simple, pdp_class = pd_full_cov$new("lm"), 
                               n = 5000, reps = 10000)


## Retrieve results ----
if (file.exists("registry_general_lin")){
  reg <- loadRegistry("./registry_general_lin", writeable = TRUE)  
  
  results <- reduceResultsDataTable()
  
  #summary table
  pars <- unwrap(getJobPars())
  tab = ijoin(pars, results)
  
  #bind actual results 
  result_table <- rbindlist(results$result)
  #perform sanity checks 
  checks <- check_results(result_table)
  checks
  coverages <- compute_coverage(result_table, true_pdp_linear)
  coverage_summary <- summary_tab(coverages)
  write.csv(tab[,1:(ncol(tab)-1)], "./registry_general_lin/summary_linear_mb.csv")
  write.csv(coverages, "./registry_general_lin/coverage_linear_mb.csv")
  print(xtable(coverage_summary, type = "latex"), file = "./registry_general_lin/coverage_summary_linear_mb.tex")
}


if (file.exists("registry_general_nonlin")){
  reg <- loadRegistry("./registry_general_nonlin", writeable = TRUE)  
  
  results <- reduceResultsDataTable()
  
  #summary table
  pars <- unwrap(getJobPars())
  tab = ijoin(pars, results)
  
  #bind actual results 
  result_table <- rbindlist(results$result)
  #perform sanity checks 
  checks <- check_results(result_table)
  checks
  coverages <- compute_coverage(result_table, true_pdp_nonlinear)
  coverage_summary <- summary_tab(coverages)
  write.csv(tab[,1:(ncol(tab)-1)], "./registry_general_nonlin/summary_nonlinear_mb.csv")
  write.csv(coverages, "./registry_general_nonlin/coverage_nonlinear_mb.csv")
  print(xtable(coverage_summary, type = "latex"), file = "./registry_general_nonlin/coverage_summary_nonlinear_mb.tex")
}